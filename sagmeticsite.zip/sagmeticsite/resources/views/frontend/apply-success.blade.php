@extends('masterlayout.website_frontend.layout')
@section('content') 

<section class="banner-sec " id="banner" >
<div class="container">
    <h3>Application for the postion : {{$job->title}} has been Submitted !</h3>
</div>
</section>