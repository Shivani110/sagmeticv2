<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h4>A new user has been added successfully</h4>
    <p>Name : <?php echo e($adduser['name']); ?></p>
    <p>Email : <?php echo e($adduser['email']); ?></p>
    <p>Phone : <?php echo e($adduser['phone']); ?></p>
</body>
</html><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/emails/user-add-mail.blade.php ENDPATH**/ ?>