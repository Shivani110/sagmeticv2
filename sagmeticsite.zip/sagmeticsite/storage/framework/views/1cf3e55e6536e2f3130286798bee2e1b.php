<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h5>Congratulations <?php echo e($applicant['name']); ?> You have been invited for The interview</h5>
    <p>Position: <?php echo e($applicant->jobs['title']); ?></p>
    <p>Message: <?php echo e($msg); ?></p>
    <p>Scheduled Time: <?php echo e($interview['scheduled_at']->format('h:i a')); ?></p>
    <p>Scheduled Date : <?php echo e($interview['scheduled_at']->format('Y-m-d')); ?></p>
</body>
</html><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/emails/user-email/invite.blade.php ENDPATH**/ ?>