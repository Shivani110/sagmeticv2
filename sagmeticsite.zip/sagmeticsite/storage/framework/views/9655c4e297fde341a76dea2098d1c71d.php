<?php $__env->startSection('content'); ?>
<!-- Join-section -->  
<section class="top-banner-sec">
    <div class="container">
        <div class="top-banner-content">
            <div class="row">
                <div class="col-md-6 top-banner-heading">
                    <h1>Join Our Team</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                          <li class="breadcrumb-item"><a href="<?php echo e(url('/'.'#home')); ?>">HOME</a></li>
                          <li class="breadcrumb-item"><a href="./ourservices.html">OUR SERVICES</a></li>
                          <li class="breadcrumb-item active" aria-current="page">CAREERS</li>
                        </ol>
                      </nav>
                </div>
                <div class="col-md-6">
                    <img class="img-fluid" src="<?php echo e(asset('website_frontend/images/jointeam.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="trending-sec">
    <div class="container">
        <div class="trending-content">
            <div class="lets-work">
              <div class="red-heading top-heading" data-aos="zoom-in-up">
                <h5>Lets work together</h5>
              </div>
                <h2>Trending Opportunities</h2>
                <p>Join our team and work with specialists in each of their fields. Improve your abilities every day by working with the top professionals in the field. Take a look at our career options and start down the path to excellence in your field.</p>
            </div>
            <div class="row">
                <?php $jobs = App\Models\Jobs::all(); ?>
                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                    <div class="hover-box">
                        <div class="line1"></div>
                        <div class="line2"></div>
                        <div class="line3"></div>
                        <div class="line4"></div>
                        <div class="job-content">
                        <div class="jobs">
                        <div class="icon">
                            <img class="img-fluid" src="<?php echo e(asset($job->icon_url)); ?>" alt="">
                        </div>
                            <h3><?php echo e($job->title); ?></h3>
                        </div>
                        <a href="#">MOHALI</a>
                        <p>Experience Required: <?php echo e($job->experience); ?></p>
                        <div class="button">
                            <a href="<?php echo e(url('/careers/'.$job->title)); ?>" class="btn" >Apply Now   <img class="img-fluid" src="<?php echo e(asset('website_frontend/images/button-polygon')); ?>.svg" alt=""></a>
                        </div>
                        </div>
                    </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<section class="main-img-sec">
    <div class="container">
        <div class="main-img-content">
            <img src="<?php echo e(asset('website_frontend/images/careerbg.png')); ?>" class="img-fluid" alt="">
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.website_frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/frontend/careers.blade.php ENDPATH**/ ?>