<?php $__env->startSection('content'); ?>

<style>
.ri-more-2-fill{
    font-weight: bolder
}
.job-filter{
    margin-right: 5%;
}
.btn{
    border-radius: 0px;
   
}
.dropdown .btn{
    width: 180px
}
</style>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('admin/home')); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Jobs</li>
    </ol>
</nav>

    <div class="showing-jobs d-flex">
        <div>
            <h4>Jobs</h4>
            <?php $jobs = App\Models\Jobs::all(); ?>
            <p>Showing <?php echo e($jobs->count()); ?> Jobs</p>
        </div>
        <div class="job-filter ms-auto">
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Sort By : Newest
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Action</a></li>
                  <li><a class="dropdown-item" href="#">Another action</a></li>
                  <li><a class="dropdown-item" href="#">Something else here</a></li>
                </ul>
                <a href="<?php echo e(url('admin/add-jobs')); ?>" class="btn btn-sm btn-danger ">Add Job</a>
              </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
            <table class="table card-table" >
                <tr>
                    
                    <th>Jobs</th>
                    <th>Salary</th>
                    <th>Added On</th>
                    <th>Experience</th>
                    <th>Applied</th>
                    <th></th>
                </tr>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        
                        <td><img src="<?php echo e(asset('images/jobicons/'.$job->icon_url)); ?>" alt="" width="50px"> <?php echo e($job->title); ?></td>
                        <td><?php echo e($job->salary); ?></td>
                        <td><?php echo e($job->created_at); ?></td>
                        <td><?php echo e($job->experience); ?></td>
                        <?php $count = App\Models\JobsApplied::where('job_id',$job->id)->count() ?>
                        <td><a href="<?php echo e(url('/admin/jobs/'.$job->title.'/applied')); ?>" class="btn btn-sm btn-outline-danger px-4"><?php echo e($count); ?></a></td>
                        <td>
                            <div class="btn-group ">
                                <button type="button" class="btn" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="ri-more-2-fill" style="" ></i>
                                    </button>
                                    <ul class="dropdown-menu">
                                        <li><a class="dropdown-item" href="<?php echo e(url('/admin/jobs/'.$job->title.'/details')); ?>">Details</a></li>
                                        <li><a class="dropdown-item" href="<?php echo e(url('/admin/jobs/'.$job->title.'/applied')); ?>">Applied</a></li>
                                        <li><a class="removeJob dropdown-item"  href="#" data-id="<?php echo e($job->id); ?>">Remove</a></li>
                                    </ul>
                                </div>  
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<script>
    $('.removeJob').on('click',function () {
        id = $(this).data('id');
        
        if(confirm('Do you Want to delete this Job Posting ?')){
         $(this).closest('tr').remove();
         $.ajax({
             type: "get",
             url: "<?php echo e(url('/removeJob')); ?>",
             data: {
                 id:id,
             },
             success: function (response) {
                 iziToast.success({
                    title: 'Job Listing Removed'
                 })
             }
         });
        }
       
      })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/admin/jobs.blade.php ENDPATH**/ ?>