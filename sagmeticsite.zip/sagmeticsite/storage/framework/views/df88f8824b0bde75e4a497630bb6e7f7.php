<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php $added_by =  App\Models\User::where('id',$add_job['added_by'])->first(); ?>
    <h4>New job Listing Added</h4>
    <p>Job AddedBY : <?php echo e($added_by['name']); ?> Email :<?php echo e($added_by['email']); ?></p>
    <p>Job Title : <?php echo e($add_job['title']); ?></p>
    <p>Job department : <?php echo e($add_job['department']); ?></p>
    <p>Job salary : <?php echo e($add_job['salary']); ?></p>
</body>
</html><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/emails/admin_emails/job-added-mail.blade.php ENDPATH**/ ?>