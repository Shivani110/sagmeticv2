<?php $__env->startSection('content'); ?>


<h4>jobs posted </h4>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.website_frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/frontend/jobs.blade.php ENDPATH**/ ?>