<?php $__env->startSection('content'); ?>

<style>
.ri-more-2-fill{
    font-weight: bolder
}
.job-filter{
    margin-right: 5%;
}
.btn{
    border-radius: 0px;
   
}
.dropdown .btn{
    width: 180px
}
</style>

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(url('admin/jobs')); ?>">Jobs</a></li>
      <li class="breadcrumb-item active" aria-current="page">Applied</li>
    </ol>
</nav>
    <div class="showing-jobs d-flex">
        <div>
            <h4>Applied</h4>
            <p>Showing 10 applicants</p>
        </div>
        <div class="job-filter ms-auto">
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-dark dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Sort By : Newest
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Action</a></li>
                  <li><a class="dropdown-item" href="#">Another action</a></li>
                  <li><a class="dropdown-item" href="#">Something else here</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-body">
    <table class="table card-table" >
        <tr>
            <th>Name</th>
            <th>Applied Date</th>
            <th>Position</th>
            <th>Contact</th>
            <th>Status</th>
            <th></th>
        </tr>
        <tbody>
            <?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>           
                <tr>
                    <td><?php echo e($applicant->name); ?></td>
                    <td><?php echo e($applicant->created_at->format('Y-m-d')); ?></td>
                    <td><?php echo e($job->title); ?></td>
                    <td><?php echo e($applicant->email); ?></td>
                    <td><a href="#" class="btn btn-sm btn-outline-danger"><?php echo e($applicant->current_status); ?></a></td>
                    <td>
                        <div class="btn-group ">
                            <button type="button" class="btn" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="ri-more-2-fill" style="" ></i>
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(url('/admin/jobs/'.$job->title.'/applied/'.$applicant->name)); ?>">Details</a></li>
                                <li><a class="dropdown-item" href="#">Remove</a></li>
                            </ul>
                    </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>         
        </tbody>
    </table>
        </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/admin/applied.blade.php ENDPATH**/ ?>