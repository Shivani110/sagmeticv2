<?php $__env->startSection('content'); ?> 

<section class="banner-sec " id="banner" >
<div class="container">
    <h3>Application for the postion : <?php echo e($job->title); ?> has been Submitted !</h3>
</div>
</section>
<?php echo $__env->make('masterlayout.website_frontend.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/frontend/apply-success.blade.php ENDPATH**/ ?>