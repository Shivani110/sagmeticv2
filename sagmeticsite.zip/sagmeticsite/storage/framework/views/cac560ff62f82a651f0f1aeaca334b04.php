<?php $__env->startSection('content'); ?>

<style>
    .btn{
        border-radius: 0px;
        
       
    }
    .card{
        border-radius: 0px
    }
</style>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Manage Users</li>
    </ol>
</nav>
<div class="container">
    <div class="page-title">
        <h4>User Management</h4>
        <p>Manage User</p>
    </div>
    <div class="row mx-3">
        <?php $users =  App\Models\User::where('role',2)->get(); ?>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
        <div class="card col-5 mx-2 p-4 d-flex">
            <div class="row g-0">
                <div class="col-md-6">
                    <div class="card-title ">
                    <h4><?php echo e($user->name); ?></h4>
                    </div>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($user->email); ?></h6>
                </div>
                <div class="col-md-6">

                    <div class="card-body ">
                        <a href="#" class="btn btn-outline-secondary">Edit</a>
                        <a href="#" class="btn btn-outline-danger">Remove</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/admin/manage-users.blade.php ENDPATH**/ ?>