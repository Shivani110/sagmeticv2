<?php $__env->startSection('content'); ?>

<style>
    .btn-outline-danger{
        border-radius: 0px;
        width: 150px; 
    }
    .errormsgs{
        color: red;
        margin-left: 2%
    }

</style>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">add user</li>
    </ol>
</nav>
<div class="page-title">
    <h4>User Management</h4>
    <p>Add HR</p>
</div>



<form class="row g-3" action="<?php echo e(url('/add-user')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="col-md-6">
        <label for="inputEmail4" class="form-label">Name</label>
        <input type="text" class="form-control" name="username"  id="inputEmail4" placeholder="Enter Name">
    <span class="errormsgs">
        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
             <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>
    <div class="col-md-6">
        <label for="inputPassword4" class="form-label">Phone</label>
        <input type="tel" class="form-control" name="userphone" id="inputEmail4" placeholder="Contact no..." minlength="10" min="10" max="10">
    <span class="errormsgs">
        <?php $__errorArgs = ['userphone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            The Phone field is required.
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>
    <div class="col-6">
        <label for="inputAddress" class="form-label">Email</label>
        <input type="email" class="form-control" name="useremail" id="inputEmail4" placeholder="abc@gmail.com">
    <span class="errormsgs">
        <?php $__errorArgs = ['useremail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>
    <div class="col-6">
        <label for="inputAddress2" class="form-label">Password</label>
        <input type="password" class="form-control" name="userpassword" id="inputSkills" placeholder="Enter Password"  autocomplete="off">
    <span class="errormsgs">
        <?php $__errorArgs = ['userpassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </span>
    </div>
    <div class="col-5">
    <button class="btn btn-outline-danger">Save</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sagmetic/sagmeticsite/resources/views/admin/add-user.blade.php ENDPATH**/ ?>