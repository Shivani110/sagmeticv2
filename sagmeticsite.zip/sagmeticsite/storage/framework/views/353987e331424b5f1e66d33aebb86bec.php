<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.0.1/remixicon.css" integrity="sha512-ZH3KB6wI5ADHaLaez5ynrzxR6lAswuNfhlXdcdhxsvOUghvf02zU1dAsOC6JrBTWbkE1WNDNs5Dcfz493fDMhA==" crossorigin="anonymous" referrerpolicy="no-referrer" />    <title>Your Page Title</title>
</head>
<style>
    .sidebar{
        background-color: black;
    }
    .sidebar-items{
        color: white;
    }
    .icons{
        font-size: 20px;
    }
    .list-group-item{
        padding: 10px;
    }
    .list-group-item:hover{
       
        background-color: red;
        border-top-left-radius: 100px;
        border-bottom-left-radius: 100px;
    }
</style>
<body>

    <!-- NAVBAR START -->
    <header>
        <nav class="navbar navbar-expand-lg bg-light">
            <div class="container-fluid">
                <div class="col-3">
                <h4>Sagmetic Infotech</h4>
            </div>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <div class="p-2"><h5>Dashboard</h5></div>
                    <div class="p-2 ms-auto">User</div>
                </div>
            </div>
        </nav>
    </header>
    <!-- NAVBAR END -->


    <div class="row">
     <!-- SIDEBAR START -->
    <div class="sidebar col-3 d-flex flex-column" style="height: 100vh">
        <div class="sidebar-items  ms-5">

            <div class="items mt-4 mb-4">
            <a href="#" class="list-group-item list-group-item-action active text-bg-danger p-2" style="border-top-left-radius: 100px;border-bottom-left-radius: 100px;" aria-current="true">
               <i class="icons ri-home-2-line"></i> Dashboard
            </a>
            </div>
            <div class="items mt-4 mb-4">
            <a href="#" class="list-group-item list-group-item-action" aria-current="true">
               <i class="icons ri-suitcase-line"></i> Jobs
            </a>
            </div>
            <div class="items mt-4 mb-4">
            <a href="#" class="list-group-item list-group-item-action " aria-current="true">
                <i class="icons ri-group-line"></i> Interview
            </a>
            </div> 
            <div class="items mt-4 mb-4">
            <a href="#" class="list-group-item list-group-item-action " aria-current="true">
                <i class="icons ri-team-line"></i> User Management
            </a>
            </div>
        </div>
    </div>
    <!-- SIDEBAR END -->


    <!-- MAIN CONTENT -->
        <div class="main-content col-9">
            main content
        </div>
    <!-- MAIN CONTENT END -->
   
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/sagmetic/sagmeticsite/resources/views/welcome.blade.php ENDPATH**/ ?>