<?php

namespace App\Http\Controllers;

use App\Models\Jobs;
use App\Models\JobsApplied;
use Illuminate\Http\Request;

class AdminViewsController extends Controller
{

}
